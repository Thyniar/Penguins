<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Your Penguin</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
        <link href="CSS/fontawesome-free-5.0.3/web-fonts-with-css/css/fontawesome-all.min.css" rel="stylesheet" type="text/css"/>
        <link href="CSS/addresse.css" rel="stylesheet" type="text/css"/>

    </head>
    <body>
        <?php session_start(); ?>

        <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #3d5474;">
            <a class="navbar-brand" href="index.php">
                <img src="Images/logoMenu2.png" alt=""/>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars fa-2x"></i>
            </button>
            <div class="collapse navbar-collapse navbarNav menu">
                <ul class="navbar-nav">
                    <li><a href="Penguins.php"><i class="far fa-snowflake"></i> Penguins</a></li>
                    <li><a href="CuddlyToys.php"><i class="fab fa-linux"></i> Cuddly Toys</a></li> 
                </ul>
            </div>
            <div class="collapse navbar-collapse navbarNav justify-content-md-end menu">
                <ul class="navbar-nav">
                    <?php
                    if (isset($_SESSION['login']) && isset($_SESSION['password'])) {
                        echo '<li><a href="membres.php"><i class="fa fa-user" style="font-size:30px;"></i></a></li>';
                        echo '<li><a href="Logout.php"><i class="fa fa-sign-out"></i> Log out </a></li>';
                    } else {
                        echo '<li><a href="Log.php"><i class="fa fa-user-plus"></i> Sign Up </a></li>';
                        echo '<li><a href="Log.php"><i class="fas fa-sign-in-alt"></i> Sign In </a></li>';
                    }
                    ?>
                    <li><a href="Contact.php"><i class="fa fa-address-book"></i> Contact</a>
                    <li><a href="panier.php"><i class="fa fa-shopping-cart" id="caddie"></i></a></li>
                </ul>
            </div>
        </nav>


        <div class="container col-lg-4 col-lg-offset-4"id="AddAddress">
            <h1><b>Add a new address</b></h1>
            <br>
            <form method="post" name="addresse">
                <div class="input-group margin-bottom-sm">
                    <span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
                    <input class="form-control" type="text" name="full_name" placeholder="Full name">
                </div>
                <br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-building fa-fw"></i></span>
                    <input class="form-control" type="text" name="num_voie" placeholder="Number">
                </div>
                <br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
                    <input class="form-control" type="text" name="nom_voie" placeholder="Street name">
                </div>
                <br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-map-signs fa-fw"></i></span>
                    <input class="form-control" type="text" name="cp" placeholder="Zip Code">
                </div>
                <br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-map fa-fw"></i></span>
                    <input class="form-control" type="text" name="nom_ville" placeholder="City">
                </div>
                <br>
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-globe fa-fw"></i></span>
                    <input class="form-control" type="text" name="pays" placeholder="State / Province / Region">
                </div>
                <br>
                <button type="submit" name="validerAddress"class="btn btn-default pull-right">Add Adress</button>       
            </form>
        

        <?php

        function ErrorMessage($mot) {

            echo "<br>le champs $mot n'est pas remplis !";
        }

        try {
            //Permet de rÃ©cuperer les donnÃ©es de la base de donnÃ©e
            $bdd = new PDO('mysql:host=localhost;dbname=penguins;charset=utf8', 'root', '');
        } catch (Exception $e) { // Si erreur
            die('Erreur : ' . $e->getMessage());
        }
        $cmpt = 6;

        if (isset($_POST['validerAddress'])) {

            if (empty($_POST['full_name'])) {
                ErrorMessage('full_name');
                $cmpt--;
            }

            if (empty($_POST['num_voie'])) {
                ErrorMessage('num_voie');
                $cmpt--;
            }

            if (empty($_POST['nom_voie'])) {
                ErrorMessage('nom_voie');
                $cmpt--;
            }

            if (empty($_POST['cp'])) {
                ErrorMessage('cp');
                $cmpt--;
            }

            if (empty($_POST['nom_ville'])) {
                ErrorMessage('nom_ville');
                $cmpt--;
            }

            if (empty($_POST['pays'])) {
                ErrorMessage('pays');
                $cmpt--;
            }


            if ($cmpt == 6) {
                $fullName = $_POST['full_name'];
                $numVoie = $_POST['num_voie'];
                $nomVoie = $_POST['nom_voie'];
                $cp = $_POST['cp'];
                $nomVille = $_POST['nom_ville'];
                $pays = $_POST['pays'];
                $idMembre = $_SESSION['id'];

                $req = $bdd->prepare('INSERT INTO addresses(full_name,num_voie,nom_voie,cp,nom_ville,pays, id_membre)'
                        . ' VALUES(:full_name, :num_voie, :nom_voie, :cp , :nom_ville, :pays, :id_membre)');
                $req->execute(array(
                    ':full_name' => $fullName,
                    ':num_voie' => $numVoie,
                    ':nom_voie' => $nomVoie,
                    ':cp' => $cp,
                    ':nom_ville' => $nomVille,
                    ':pays' => $pays,
                    ':id_membre' => $idMembre
                ));
                
                echo'<br><div class="alert alert-success">
                                Address added successfully ! <a href="membres.php">Back to your account</a>
                                </div>';
            }
        }
       
        ?>
        </div>

        <div class="row fixed-bottom" id="footer">                   
            <div class="col-lg-12" id="sociaux">
                <ul>
                    <li><a href="https://www.facebook.com/Your-penguin-370472053409761"><i class="fab fa-facebook-square"></i></a></li>
                    <li><a href="https://twitter.com/GetPenguin6"><i class="fab fa-twitter"></i></a>
                    <li><a href="#"><i class="fab fa-instagram"></i></a>
                </ul>
                <p><i class="fa fa-copyright"></i> copyright. All rights reserved.</p>
            </div>
        </div>

    </body>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" integrity="sha384-a5N7Y/aK3qNeh15eJKGWxsqtnX/wWdSZSKp+81YjTmS15nvnvxKHuzaWwXHDli+4" crossorigin="anonymous"></script>
</html>
