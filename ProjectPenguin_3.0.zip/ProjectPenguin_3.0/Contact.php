<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Your Penguin</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
        <link href="CSS/fontawesome-free-5.0.3/web-fonts-with-css/css/fontawesome-all.min.css" rel="stylesheet" type="text/css"/>
        <link href="CSS/Contact.css" rel="stylesheet" type="text/css"/>

    </head>
    <body>
        <?php session_start(); ?>

        <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #3d5474;">
            <a class="navbar-brand" href="index.php">
                <img src="Images/logoMenu2.png" alt=""/>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars fa-2x"></i>
            </button>
            <div class="collapse navbar-collapse navbarNav menu">
                <ul class="navbar-nav">
                    <li><a href="Penguins.php"><i class="far fa-snowflake"></i> Penguins</a></li>
                    <li><a href="CuddlyToys.php"><i class="fab fa-linux"></i> Cuddly Toys</a></li> 
                </ul>
            </div>
            <div class="collapse navbar-collapse navbarNav justify-content-md-end menu">
                <ul class="navbar-nav">
                    <?php
                    if (isset($_SESSION['login']) && isset($_SESSION['password'])) {
                        echo '<li><a href="membres.php"><i class="fa fa-user" style="font-size:30px;"></i></a></li>';
                        echo '<li><a href="Logout.php"><i class="fas fa-sign-out-alt"></i> Log out </a></li>';
                    } else {
                        echo '<li><a href="Log.php"><i class="fa fa-user-plus"></i> Sign Up </a></li>';
                        echo '<li><a href="Log.php"><i class="fas fa-sign-in-alt"></i> Sign In </a></li>';
                    }
                    ?>
                    <li><a href="Contact.php"><i class="fa fa-address-book"></i> Contact</a>
                    <li><a href="panier.php"><i class="fa fa-shopping-cart" id="caddie"></i></a></li>
                </ul>
            </div>
        </nav>

        <div class="row justify-content-center" id="contact">
            <div class="col-lg-4">
                <h1>Contact us :</h1>
                <br>
                <form>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
                        <input class="form-control" type="text" placeholder="Name">
                    </div>
                    <br>
                    
                    <div class="input-group margin-bottom-sm">
                        <span class="input-group-addon"><i class="fa fa-user fa-fw"></i></span>
                        <input class="form-control" type="text" placeholder="Surname">
                    </div>
                    <br>
                    <div class="input-group margin-bottom-sm">
                        <span class="input-group-addon"><i class="fa fa-info fa-fw"></i></span>
                        <input class="form-control" type="text" placeholder="Subject">
                    </div>
                    <br>
                    <div class="input-group margin-bottom-sm">
                        <span class="input-group-addon"><i class="fa fa-envelope fa-fw"></i></span>
                        <input class="form-control" type="email" placeholder="Email address">
                    </div>
                    <br><br>
                    <div class="input-group margin-bottom-sm">
                        <span class="input-group-addon"><i class="fa fa-comment fa-fw"></i></span>
                        <textarea class="form-control" rows="5" id="description"></textarea>
                    </div>
                    <br>
                    <button type="submit" class="btn btn-default">Submit</button>
                    <br>
                </form>                  
            </div>
            <div class="col-lg-6" id="info">
                <h1>Information :</h1>
                <ul>
                    <li>
                        <h3>Address :</h3>
                        <P>ISEN TOULON</p>
                        <p>Place Georges Pompidou</p>
                        <p>83000 Toulon</p>
                        <p>France</p>
                    </li>
                    <li>
                        <h3>Mail :</h3>
                        <a href="yourpenguin83@gmail.com">yourpenguin83@gmail.com</a>
                    </li>
                    <li>
                        <h3>Phone :</h3>
                        <p>(000) 000-0000</p>
                    </li>
                </ul>
            </div>
        </div>

        <br><br>

        <div class="row fixed-bottom" id="footer">                   
            <div class="col-lg-12" id="sociaux">
                <ul>
                    <li><a href="https://www.facebook.com/Your-penguin-370472053409761"><i class="fab fa-facebook-square"></i></a></li>
                    <li><a href="https://twitter.com/GetPenguin6"><i class="fab fa-twitter"></i></a>
                    <li><a href="#"><i class="fab fa-instagram"></i></a>
                </ul>
                <p><i class="fa fa-copyright"></i> copyright. All rights reserved.</p>
            </div>
        </div>
    </body>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" integrity="sha384-a5N7Y/aK3qNeh15eJKGWxsqtnX/wWdSZSKp+81YjTmS15nvnvxKHuzaWwXHDli+4" crossorigin="anonymous"></script>
</html>
