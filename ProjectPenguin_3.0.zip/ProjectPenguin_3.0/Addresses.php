<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Your Penguin</title>
        <link href="CSS/addresse.css" rel="stylesheet" type="text/css"/>
        <link href="CSS/fontawesome-free-5.0.3/web-fonts-with-css/css/fontawesome-all.min.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">
    </head>
    <body>
        <?php session_start(); ?>
        <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #3d5474;">
            <a class="navbar-brand" href="index.php">
                <img src="Images/logoMenu2.png" alt=""/>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars fa-2x"></i>
            </button>
            <div class="collapse navbar-collapse navbarNav menu">
                <ul class="navbar-nav">
                    <li><a href="Penguins.php"><i class="far fa-snowflake"></i> Penguins</a></li>
                    <li><a href="CuddlyToys.php"><i class="fab fa-linux"></i> Cuddly Toys</a></li> 
                </ul>
            </div>
            <div class="collapse navbar-collapse navbarNav justify-content-md-end menu">
                <ul class="navbar-nav">
                    <?php
                    if (isset($_SESSION['login']) && isset($_SESSION['password'])) {
                        echo '<li><a href="membres.php"><i class="fa fa-user" style="font-size:30px;"></i></a></li>';
                        echo '<li><a href="Logout.php"><i class="fas fa-sign-out-alt"></i> Log out </a></li>';
                    } else {
                        echo '<li><a href="Log.php"><i class="fa fa-user-plus"></i> Sign Up </a></li>';
                        echo '<li><a href="Log.php"><i class="fas fa-sign-in-alt"></i> Sign In </a></li>';
                    }
                    ?>
                    <li><a href="Contact.php"><i class="fa fa-address-book"></i> Contact</a>
                    <li><a href="panier.php"><i class="fa fa-shopping-cart" id="caddie"></i></a></li>
                </ul>
            </div>
        </nav>

        <div class="container" id="AddAddress">

            <h1 class="my-4 text-center text-lg-left">Add Your Address</h1>

            <div class="row text-center text-lg-left">

                <div class="col-lg-3 col-md-4 col-xs-6" id="block1">
                    <a href="AddAdresses.php" class="d-block mb-4 h-100">
                        <i class="d-flex justify-content-center fas fa-plus"></i>
                    </a>
                </div>
                
                 
                    <?php
                    try {
                        //Permet de rÃ©cuperer les donnÃ©es de la base de donnÃ©e
                        $bdd = new PDO('mysql:host=localhost;dbname=penguins;charset=utf8', 'root', '');
                    } catch (Exception $e) { // Si erreur
                        die('Erreur : ' . $e->getMessage());
                    }
                    $id = $_SESSION['id'];
                    $reponse = $bdd->query("SELECT * FROM addresses WHERE id_membre ='$id'");
                    $donnees = $reponse->fetch();

                    if ($donnees['id_add'] != NULL) {
                       echo '<div class="col-lg-3 col-md-4 col-xs-6" id="block2">';
                        echo "<p><b>" . $donnees['full_name'] . "</b></p>";
                        echo "<p>" . $donnees['num_voie'] . ' ' . $donnees['nom_voie'] . "</p>";
                        echo "<p>" . $donnees['cp'] . ' ' . $donnees['nom_ville'] . "</p>";
                        echo "<p>" . $donnees['pays'] . "</p>";                        
                        ?>
                    <form method="post"><div id="lienmodif"><button name="delete">Delete</button></div></form>                
                    <?php
                    echo "</div>";
                }
                ?>
                
                <?php
                try {
                    //Permet de rÃ©cuperer les donnÃ©es de la base de donnÃ©e
                    $bdd = new PDO('mysql:host=localhost;dbname=penguins;charset=utf8', 'root', '');
                } catch (Exception $e) { // Si erreur
                    die('Erreur : ' . $e->getMessage());
                }
                if (isset($_POST['delete'])) {
                    $req = $bdd->query("DELETE FROM addresses WHERE id_membre='$id'");
                    $req->execute();
                }
                ?>
            </div>
        </div>



        <div class="row fixed-bottom" id="footer">                   
            <div class="col-lg-12" id="sociaux">
                <ul>
                    <li><a href="https://www.facebook.com/Your-penguin-370472053409761"><i class="fab fa-facebook-square"></i></a></li>
                    <li><a href="https://twitter.com/GetPenguin6"><i class="fab fa-twitter"></i></a>
                    <li><a href="#"><i class="fab fa-instagram"></i></a>
                </ul>
                <p><i class="fa fa-copyright"></i> copyright. All rights reserved.</p>
            </div>
        </div>

    </body>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" integrity="sha384-a5N7Y/aK3qNeh15eJKGWxsqtnX/wWdSZSKp+81YjTmS15nvnvxKHuzaWwXHDli+4" crossorigin="anonymous"></script>
</body>
</html>
